﻿using MessengerApplication.Abstraction;
using MessengerApplication.Models;
using System.Reflection.Metadata.Ecma335;

namespace MessengerApplication.Mock
{
    //public class AuthenticationMock : IUserAuthenticationService
    //{
    //    public User Authenticate(UserLogin model)
    //    {
    //        if (model.Email == "admin@mail.ru" && model.Password == "admin")
    //        {
    //            return new User { Password = model.Password, Email = model.Email, Role = RoleId.Admin };
    //        }

    //        if (model.Email == "user@mail.ru" && model.Password == "user")
    //        {
    //            return new User { Password = model.Password, Email = model.Email, Role = RoleId.User };
    //        }

    //        return null;
    //    }
    //}
}
