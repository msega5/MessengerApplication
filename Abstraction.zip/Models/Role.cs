﻿namespace MessengerApplication.Models
{
    public partial class Role
    {
        public RoleId RoleId { get; set; }
        public string Email { get; set; }
        //public string List<User> Users { get; set;}
    }
}
