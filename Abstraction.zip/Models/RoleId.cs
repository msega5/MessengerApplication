﻿namespace MessengerApplication.Models
{
    public enum RoleId
    {
        Admin = 0,
        User = 1
    }
}
